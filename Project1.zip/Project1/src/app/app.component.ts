import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit{
  title = 'orderFrontEnd';
  userId = 'abc@gmail.com';
  ordersList: Array<any>=new Array<any>();
  workingList: Array<any>=new Array<any>();
  showCancelOrderButton : boolean = false;
  showReturnButtonHeader : boolean = false;
  cancelButtonChecked : boolean = false;
  returnButtonChecked: boolean = false;

  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    let url = "http://localhost:8080/" + this.userId + "/orders";

    this.http.get<any>(url).subscribe(data=>{
      this.ordersList = data;

      for(let i =0;i<this.ordersList.length;i++){ 
        var date = new Date(this.ordersList[i].orderDate);
        this.ordersList[i].orderDate = date.toUTCString();
      }
      // Deep copy of orderslist
      this.workingList = JSON.parse(JSON.stringify(this.ordersList)) as typeof this.ordersList});

  console.log(this.ordersList);
}

public showOrders(clickedStatus:any){
  if(clickedStatus=="open"){
    this.showCancelOrderButton = true;
  }
  else{
    this.showCancelOrderButton = false;
  }
  if((clickedStatus=='delivered')){
    this.showReturnButtonHeader=true;
  }
  else{
    this.showReturnButtonHeader=false;
  }
  

    this.workingList.splice(0);
    for(let i=0;i<this.ordersList.length;i++){
      if(this.ordersList[i].status == clickedStatus){
        var openedOrder = this.ordersList[i];
        if((clickedStatus=='delivered') && (!(this.isOrderOlderThanTenDays(openedOrder.orderDate)))){
          openedOrder.showReturnButton=true;
        }
        else{
          openedOrder.showReturnButton=false;
        }
        this.workingList.push(openedOrder);
      }
    }
}

public cancelOrder(orderId:any, indexId:any){
  // let orderId : any = "29b58471-08a4-11e7-ab76-335ccb31dea";
  let url = "http://localhost:8080/" + this.userId + "/orders/" + orderId + "/cancel";
  
  let isCancelled = this.http.post<any>(url,null).subscribe(
    (response) => {
      return response;
    });

    if(isCancelled)
    {
      this.workingList[indexId].status  = "cancelled";
      this.ordersList[this.getOrderListIndex(this.workingList[indexId].orderId)].status  = "cancelled";
      // this.cancelButtonChecked = true;
      this.showOrders("open");
    }

}

public returnOrder(orderId:any , indexId: any){
  let url ="http://localhost:8080/" + this.userId + "/orders/" + orderId + "/return";

  let isReturned = this.http.post<any>(url,null).subscribe((response)=>{
    return response;
  });
  if(isReturned)
  {
    this.workingList[indexId].status = "returned";
    this.ordersList[this.getOrderListIndex(this.workingList[indexId].orderId)].status = "returned";
    // this.returnButtonChecked = true;
    this.showOrders("delivered");
    
  }
}

public isOrderOlderThanTenDays(dateString:any): boolean {
  let orderedDate = new Date(dateString);
  let numOrderedDate =  orderedDate.getTime();
  let nowDate : Date = new Date();
  let numNowDate = nowDate.getTime();
  const diffInMs = Math.abs(numNowDate-numOrderedDate);
  return (diffInMs / (1000 * 60 * 60 * 24)) > 10 ;
}

// WL - abc, def
// OL - cad, abc, efg, def, ghi
public getOrderListIndex(orderId:any){

  for(let i=0;i<this.ordersList.length;i++){
    if(this.ordersList[i].orderId == orderId){
      return i;
    }
  }
  return -1;
}

}

