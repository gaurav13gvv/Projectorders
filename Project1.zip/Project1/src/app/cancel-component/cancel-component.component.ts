import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancel-component',
  templateUrl: './cancel-component.component.html',
  styleUrls: ['./cancel-component.component.css']
})
export class CancelComponentComponent implements OnInit {

  constructor(http:HttpClient) { }

  ngOnInit(): void {
  }

}
