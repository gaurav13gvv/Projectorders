import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliverComponentComponent } from './deliver-component.component';

describe('DeliverComponentComponent', () => {
  let component: DeliverComponentComponent;
  let fixture: ComponentFixture<DeliverComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeliverComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeliverComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
