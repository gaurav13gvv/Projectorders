import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deliver-component',
  templateUrl: './deliver-component.component.html',
  styleUrls: ['./deliver-component.component.css']
})
export class DeliverComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
