import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpenComponentComponent } from './open-component.component';

describe('OpenComponentComponent', () => {
  let component: OpenComponentComponent;
  let fixture: ComponentFixture<OpenComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpenComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OpenComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
