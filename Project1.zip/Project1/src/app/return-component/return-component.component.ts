import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-return-component',
  templateUrl: './return-component.component.html',
  styleUrls: ['./return-component.component.css']
})
export class ReturnComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
