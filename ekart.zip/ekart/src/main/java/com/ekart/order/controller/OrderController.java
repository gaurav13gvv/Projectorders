package com.ekart.order.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ekart.order.entity.OrderEntity;
import com.ekart.order.service.OrderService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@CrossOrigin("*")
public class OrderController {
	
	@Autowired 
	OrderService orderService;
	
	
	
	@GetMapping("/{userId}/orders")
	public List<OrderEntity> viewOrdersList(@PathVariable String userId) {
		log.info("controller");
		return orderService.viewOrders(userId);
	}
	
	@PostMapping("/{userId}/orders/{orderId}/cancel")
	public ResponseEntity<Boolean> cancelOrder(@PathVariable String userId,@PathVariable String orderId){
		try {
			log.info(orderId);
			log.info(userId);
		boolean v = orderService.cancelOrder(orderId);
		return v ? ResponseEntity.status(HttpStatus.ACCEPTED).body(v) : 
			ResponseEntity.status(HttpStatus.CONFLICT).body(v);

		}catch(Exception e) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body(false);
		}
	}
	
	@PostMapping("/{userId}/orders/{orderId}/return")
	public ResponseEntity<Boolean> returnOrder(@PathVariable String userId,@PathVariable String orderId){
		try{
			log.info(orderId);
			log.info(userId);
			boolean w = orderService.returnOrder(orderId);
			return w ? ResponseEntity.status(HttpStatus.ACCEPTED).body(w): ResponseEntity.status(HttpStatus.CONFLICT).body(w);
				
		}catch(Exception e) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body(false);
		}
	}
	
}