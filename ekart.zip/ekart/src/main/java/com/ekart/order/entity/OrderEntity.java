package com.ekart.order.entity;

import java.time.LocalDateTime;

import javax.persistence.*;

import com.ekart.order.dto.OrderDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="orderData")
public class OrderEntity {

	@Id
	private String orderId;
	private String productName;
	private String category;
	private String seller;
	private int quantity;
	private float totalPrice;
	private LocalDateTime orderDate;
	private String status;
	
	private String userId; 
}
