package com.ekart.order.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ekart.order.entity.OrderEntity;
@Service
public interface OrderService{

	List<OrderEntity> viewOrders(String userId);

	Boolean cancelOrder(String orderId);

	Boolean returnOrder(String orderId);

}
