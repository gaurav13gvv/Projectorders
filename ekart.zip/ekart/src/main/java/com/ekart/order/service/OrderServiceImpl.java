package com.ekart.order.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import com.ekart.order.entity.OrderEntity;
import com.ekart.order.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {
	
	@Autowired
	OrderRepository orderRepository;
	
	public List<OrderEntity> viewOrders(String userId){
		return orderRepository.getByUserId(userId);
	}

	@Override
	public Boolean cancelOrder(String orderId) {
		try {
			OrderEntity order = orderRepository.findByOrderId(orderId);
			order.setStatus("cancelled");
			OrderEntity updatedOrderEntity = orderRepository.save(order);
			return (updatedOrderEntity != null);
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public Boolean returnOrder(String orderId) {
		// TODO Auto-generated method stub
		try {
			OrderEntity order1 = orderRepository.findByOrderId(orderId);
			order1.setStatus("returned");
			OrderEntity updatingOrderEntity = orderRepository.save(order1);
			return (updatingOrderEntity != null);
			
		} catch(Exception e) {
				return false;
			
		}
	}

}
